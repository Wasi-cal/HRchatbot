# Handoff: Tessa — Company Policy Assistant (Chat + Voice)

## Overview
Tessa answers employee questions about **company policies only** (leave, PTO, remote work, expenses, code of conduct, anti-harassment, info security). It has two modes: text chat and voice. Every answer cites the policy and page it came from. Users cannot upload documents — the policy library is managed by the admin.

## About the design file
`Doc Assist.dc.html` is a working HTML/React prototype that shows the layout, states and motion. **Don't ship it as-is.** Rebuild it in the real app's stack and component library. If there's no stack yet, use React + TypeScript + Tailwind (or CSS modules).

## Fidelity
High-fidelity. Match the colors, type, spacing and motion below.

## Layout
Two fixed columns, plus an optional right panel:
1. **Sidebar** (272px, white, right border `#ECECEE`)
2. **Main area** (flex, background `#FAFAFA`)
3. **Policies panel** (296px, optional, right side)

### Sidebar
- Header, 64px: a 28px black (`#18181B`) rounded-square logo with a white doc icon, then the "Tessa" wordmark (15px/700, letter-spacing -0.01em).
- "New conversation" button: full width, white, 1px `#E4E4E7` border, 9px radius, 13.5px/600. Hover: `#F4F4F5`.
- History: grouped by date ("Today", "Earlier this week"). Group labels are 11px/600, uppercase, `#A1A1AA`. Rows are 13px, 8px radius, ellipsis truncation. The active row is `#EEF2FF` with text `#4338CA` at 600 weight. Hover: `#F4F4F5`.
- Footer: 30px indigo avatar with initials, then name (12.5px/600) and role (11px, `#A1A1AA`), then icon buttons for **Policies** (toggles the right panel) and **Settings**.

### Start screen (no active conversation)
- Content is centered with a max width of 640px.
- Background: a static fade from the bottom up. `linear-gradient(to top, #E0E7FF 0%, rgba(238,242,255,0.7) 28%, transparent 62%)`. It is not animated.
- Headline: "Ask about any company policy", 28px/700, letter-spacing -0.02em, `#18181B`.
- Subtext: "Answers come straight from official company policies, always the latest version." 14.5px, `#71717A`.
- Message box (see the shared spec below).
- Four suggestion chips: pill shape, white, 1px `#E4E4E7` border, 12.5px, `#3F3F46`. Clicking a chip sends that question.

### Chat
- Header, 56px: the conversation title (13.5px/600), with a bottom border.
- Messages: 24px/28px padding, 14px gap.
  - User messages: right-aligned, accent background (`#4F46E5`), white text.
  - Tessa messages: left-aligned, `#F4F4F5` background, `#18181B` text, with a 26px black avatar tile.
  - Both: max width 560px, 11px/15px padding, 12px radius, 14px/1.55 text. They fade up into place over 0.3s.
- Citation chip under each Tessa answer: "{Policy} · p.{page}". White, 1px `#E4E4E7` border, 11.5px, indigo doc icon. Hover: `#EEF2FF` with a `#C7D2FE` border. Clicking it opens the Policies panel and highlights that policy.
- The message box is docked at the bottom.

### Voice mode
- The main area turns white and uses the same bottom-up fade as the start screen.
- Top label: "Voice mode", 13px/600, `#A1A1AA`.
- **Pixel orb:** a 14×14 grid of square cells (2px gap, 2px radius) cut into a circle. Only show cells whose normalized distance from the center is ≤ 0.74. Cell color runs from `#C7D2FE` at the center to `#4F46E5` at the edge. Opacity is about `0.3 + (1 - dist) * 0.6`. Size is `min(184px, 21vh)`. A soft indigo conic halo rotates behind it (10s per turn).
  - **Idle:** each cell shimmers (opacity 0.55↔0.95 over 2.6s). Delays are staggered by `(row + col) * 0.035s`, which makes a diagonal wave. The whole orb breathes (scale 1↔1.04 over 5s).
  - **Listening:** the orb holds at 1.12× scale.
  - **Speaking:** the orb **expands with the voice**. Its scale follows the output level, between 1.05× and 1.55×. Each cell's opacity follows the level too, weighted toward the center. In the prototype this is random; in production, drive it from the real audio (see below).
- Waveform: 28 indigo bars, 4px wide. They pulse gently when idle and follow the audio level when active.
- Status line: "Tap to talk" / "Listening…" / "Tessa is speaking" (14.5px/600). Below it, a live caption (14.5px, `#52525B`) that fades in. Reserve space for it so the layout doesn't jump.
- Bottom controls: "Back to chat" (46px, white, bordered) and "End call" (50px, `#DC2626`, hover `#B91C1C`, phone icon rotated 135°).
- Tapping the orb starts voice; tapping it while active stops.

### Policies panel
- Title "Policies", subtitle "The policies Tessa answers from".
- One row per policy: indigo doc icon, name (12.5px/600), and a meta line ("14 pages · Updated Jan 2026", 11px, `#A1A1AA`). The cited or active row is `#EEF2FF` with a `#C7D2FE` border.
- No upload control.

### Settings dialog
- 400px wide, 14px radius, scrim `rgba(24,24,27,0.4)`.
- Response style: segmented control (Concise / Balanced / Detailed). The selected option is black `#18181B` with white text.
- "Always cite sources" toggle: accent when on, `#D4D4D8` when off.
- Assistant voice: shows the current voice name.

### Shared message box
White, 1px `#E4E4E7` border, 14px radius, 6px/6px/6px/16px padding. Contains:
- Input (14.5px), placeholder "Ask about a company policy…"
- Mic button (36px, `#F4F4F5`): opens voice mode
- Send button (36px, `#18181B`, hover `#3F3F46`)

Enter sends.

## Design tokens
- Type: **Inter** 400/500/600/700
- Accent `#4F46E5` · accent hover/text `#4338CA` · accent tint `#EEF2FF` · tint border `#C7D2FE` · fade `#E0E7FF`
- Ink `#18181B` · `#3F3F46` · `#52525B` · muted `#71717A` · `#A1A1AA`
- Surfaces `#FFFFFF` · `#FAFAFA` · `#F4F4F5` · borders `#ECECEE` / `#E4E4E7` / `#D4D4D8`
- Danger `#DC2626`
- Radii: 7–9px (controls), 12–14px (bubbles, inputs, dialog), 999px (chips, toggle)
- Transitions: 0.15s ease on hover

## Implementation notes (the parts the prototype fakes)
1. **Answers (RAG):** index the policy PDFs into a vector store. Retrieve the top passages for each question, then send them to an LLM with a strict instruction: answer only from the provided policy text, otherwise say you don't know and point to People Ops. Return `{ answer, citations: [{ policy, page }] }`. Stream the answer into the bubble.
2. **Voice:** use a realtime speech API (for example OpenAI Realtime, or Deepgram/Whisper for speech-to-text plus ElevenLabs or similar for text-to-speech). Voice should use the same retrieval pipeline as chat. The status values `idle | listening | speaking` match the prototype.
3. **Orb reactivity:** connect the TTS output (or the mic input while listening) to a Web Audio `AnalyserNode`. Sample `getByteFrequencyData` on each animation frame. Map the overall level (RMS) to the orb scale (1.05–1.55) and the frequency bins to the waveform bars and cell opacity. Render the orb in a `<canvas>` rather than 196 DOM nodes, so it holds 60fps.
4. **History:** store conversations per user, grouped by date in the sidebar.
5. **Policy library:** admins manage it on the backend. Re-index when a policy is updated, and show the updated date in the panel.
6. **Settings:** response style changes the system prompt. "Cite sources" only toggles whether chips are shown; citations are always returned.

## Files
- `Doc Assist.dc.html`: the interactive prototype. Open it in a browser.
